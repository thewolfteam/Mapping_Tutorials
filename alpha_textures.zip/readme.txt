Tutorial of Alpha textures taken from www.wolfensteinx.com or from www.haradirki.de

TheWolfTeam is just referring the original sources here. 



