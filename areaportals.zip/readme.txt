Tutorials taken from www.haradirki.de or www.mapping-tutorials.de

TheWolfTeam is just referring the original sources here. 



