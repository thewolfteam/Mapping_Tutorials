Tutorial taken from www.level-designer.de

TheWolfTeam is just referring the original sources here. 



