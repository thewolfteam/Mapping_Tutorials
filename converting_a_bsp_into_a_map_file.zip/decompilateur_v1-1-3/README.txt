=============================
	Decompilateur
=============================

I] Mentions L�gales

CE LOGICIEL EST FOURNI "EN L'ETAT" SANS GARANTIE D'AUCUNE SORTE, QU'ELLE SOIT IMPLICITE OU EXPLICITE, Y COMPRIS LES GARANTIES D'APTITUDE A UN TYPE D'UTILISATION.
EN AUCUN CAS, CIDELCORP NE SERA TENU RESPONSABLE POUR TOUT DOMMAGE SPECIAL, ACCIDENTEL OU INDIRECT DECOULANT DE LA POSSESSION, DE L'UTILISATION OU DU DYSFONCTIONNEMENT DE CE LOGICIEL CIDELCORP.
CIDELCORP SE RESERVE LE DROIT DE PROCEDER A DES AMELIORATIONS SUR CE FICHIER ET SUR CE LOGICIEL A TOUT MOMENT ET SANS PREAVIS.


II] Changelog

version 1.1.2
	Ajout d'un nouveau syst�me de s�lection de jeu (l'ancien ne permettais pas de choisir facilement son jeu)
	Correction d'un bug provoquant l'arret du programme lors de la decompression des textures
	Correction d'un bug de casse pour quake 3
	Ajout du syst�me de statistiques anonymes cidelcorp ( Nom complet de l'os, version du programme, date de la decompilation)

version 1.1.1
	Correction d'un bug
	Modification du texte copi� dans le presse papier lors de crashs.

version 1.1.0
	Ajout d'une meilleure mise en evidence des probl�mes de la compilation
	Ajout du support des textures pour les 3 jeux support�s (Wolf:ET,RTCW,Quake3)
	Ajout de la reconnaissance d'une erreur d'acc�s d'�criture au fichier de sauvegarde
	Correction d'un bug qui provoquait lors des 2nd, 3emes ... compilations une impossibilit� de sauvegarder le .map sous un nom different que "converted_mapname.map"
	Ajout de ce fichier (README)

III] Support

Manuel en ligne :
	http://decompilateur.cidelcorp.fr

Forums de support :
	http://forums.cidelcorp.fr

E-Mail :
	cidelcreateur@hotmail.fr


IV] Remerciements

	Je tiens a remercier toute l'equipe de Cidelcorp et notemment le petit dernier, j'ai nomm� cubix999.
	Je tiens aussi a remercier www.enemyterritory.fr pour la news qu'ils ont post�s lors de la sortie de ce logiciel.

	Merci aussi � tous ceux qui m'entourrent de leur amour et de leur gentillesse.

	Merci sp�cial � mon p�re : "Oui, j'y ai cru ..."