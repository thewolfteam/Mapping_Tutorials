instructions to decompile BSP files with this folder:

1.) paste this folder to wherever you want but keep all files in this folder together or the decompiler will not work 

2.) paste the BSP file you wanna convert into this folder

3.) right click on the Decompiler.bat file and say 'Edit'

4.) in the line put your name of the BSP file, keep the rest of the line as it is, just exchange the map name and safe the file

5.) double click the Decompiler.bat file. The file will then be executed and creates a map  file named map mapname-converted.map in this folder. 

6.) copy the map file to wherever you want but leave the rest of the folder intact. DO NOT RIP THOSE FILES APART

Have Fun
Teuthis


